# Change Log

## 0.1.3 *2020-1-25*
* added success message type
* fix editing-to-add-DONE bug
* fixed backup deletion bug
* added --error-comments flag to edit subcommand
* added --directory option to facilitate testing in homebrew
## 0.1.2 *2020-1-23*
* adding more fractional precision options: half hour, third, etc.
## 0.1.1 *2020-1-20*
* adding JSON output as summary option
